var config = {};

config.bot = {};
config.bot.id = "198896359";
config.bot.token = "198896359:AAFEJNROxK69Sxhr3KRVIiA8jxfrxK7KpiY";

module.exports = config;
