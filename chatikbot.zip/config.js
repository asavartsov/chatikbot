var config = {};

config.bot = {}
config.bot.id = "138591196";
config.bot.token = "138591196:AAE1mRy-rZWM7qMhuyqMQH7DNqm3CWikABw";

module.exports = config;