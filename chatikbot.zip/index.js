var ScheduleHandler = require("./ScheduleHandler");
    
exports.echoHandler = function(event, context) {
    var message = event.message;
};

exports.scheduleHandler = function (event, context) {
    new ScheduleHandler(context).handle(event);
};